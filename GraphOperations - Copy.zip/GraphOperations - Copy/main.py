from graph import Graph
from user import UI

if __name__=="__main__":
    ui = UI()
    ui.start_menu()